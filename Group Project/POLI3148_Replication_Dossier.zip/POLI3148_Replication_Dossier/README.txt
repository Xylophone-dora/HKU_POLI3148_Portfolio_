Basic project information:
This project aims to discover how the level of democracy affects government spending on education. 
We are interested in the topic of democracy and education initially, and with further literature research, we discovered contrasting views on how the two variables connect, correlate, and interact with each other.
We then developed this project to examine the relationship between the two variables and give possible reasons behind the seemingly contradicting views.
The data adopted come from V-Dem (democracy level) and World Bank (government spending on education). 
Independent variables: Five High-Level Democracy Indexes (Electoral, Liberal, Participatory, Deliberative, Egalitarian)
Dependent variables: Education Expenditure as % of Government Expenditure, Education Expenditure as % of GDP (Pre-Primary, Primary, Secondary, Post-Secondary Non-Tertiary, Tertiary)

Division of labor (as the poster missed this part):
ALL MEMBERS: Proposal Writing, Data Collection, Poster Making
Jessie Tao Yujia: Data Wrangling, Data Analysis, Limitation and Conclusion
Dora Xu Yueling: Data Wrangling, Data Visualization, Discussion
Thomas Zhang Yixiang: Literature Review, Data Analysis
Ray Yang Xinrui: Data Analysis, Discussion

Instruction on how to run the code to replicate the results:
-Run all code in order would do the job. 
-Graphs are designed not to be automatically saved. 
-To view the graphs, running all chuncks before the graphs followed by running the specific chunck would be a safe option, as renaming may create objects unfound.

Notes:
1. While the object name "G_as_of_Y" may be confusing, it contains the data of Education Expenditure as % of GDP rather than Government Expenditure as % of GDP.
2. The Data Analysis tests are not plotted in the form of faceted graphs but appear as numbers, and can be seen when run individually in the chunck titled "###Testing correlations:".